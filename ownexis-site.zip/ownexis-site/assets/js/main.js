/* ============================================================
   Ownexis — site behaviour
   ------------------------------------------------------------
   CONTACT FORM ENDPOINT
   GitHub Pages serves static files only, so the form needs an
   external endpoint to deliver the message. Create a free form
   at https://formspree.io (or https://web3forms.com), then paste
   the URL below. Example:
     var FORM_ENDPOINT = "https://formspree.io/f/xxxxxxxx";

   While this is left empty, the form opens the visitor's email
   client with the message pre-filled and still shows the
   thank-you window.
   ============================================================ */
var FORM_ENDPOINT = "";
var FORM_RECIPIENT = "jose@ownexis.com";

(function () {
  "use strict";

  var isES = (document.documentElement.lang || "en").toLowerCase().indexOf("es") === 0;

  /* ---------- scroll reveal ---------- */
  if (window.IntersectionObserver) {
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (e) {
        if (e.isIntersecting) { e.target.classList.add("in"); io.unobserve(e.target); }
      });
    }, { threshold: 0.1 });
    document.querySelectorAll("section > .wrap > *").forEach(function (el, i) {
      el.classList.add("reveal");
      el.style.transitionDelay = (i % 3) * 60 + "ms";
      io.observe(el);
    });
  }

  /* ---------- mobile navigation ---------- */
  var toggle = document.querySelector(".nav-toggle");
  var links = document.getElementById("nav-links");
  if (toggle && links) {
    toggle.addEventListener("click", function () {
      var open = links.classList.toggle("open");
      toggle.setAttribute("aria-expanded", open ? "true" : "false");
    });
    links.addEventListener("click", function (e) {
      if (e.target.tagName === "A") {
        links.classList.remove("open");
        toggle.setAttribute("aria-expanded", "false");
      }
    });
  }

  /* ---------- current year ---------- */
  var yr = document.getElementById("yr");
  if (yr) { yr.textContent = new Date().getFullYear(); }

  /* ---------- thank-you modal ---------- */
  var modal = document.getElementById("thanks");
  var lastFocus = null;

  function openModal() {
    if (!modal) return;
    lastFocus = document.activeElement;
    modal.classList.add("open");
    document.body.style.overflow = "hidden";
    var btn = document.getElementById("thanks-close");
    if (btn) btn.focus();
  }
  function closeModal() {
    if (!modal) return;
    modal.classList.remove("open");
    document.body.style.overflow = "";
    if (lastFocus) lastFocus.focus();
  }
  if (modal) {
    var closeBtn = document.getElementById("thanks-close");
    if (closeBtn) closeBtn.addEventListener("click", closeModal);
    modal.addEventListener("click", function (e) { if (e.target === modal) closeModal(); });
    document.addEventListener("keydown", function (e) {
      if (e.key === "Escape" && modal.classList.contains("open")) closeModal();
    });
  }

  /* ---------- contact form ---------- */
  var form = document.getElementById("contact-form");
  if (!form) return;

  function mailtoFallback(d) {
    var subject = isES ? "Consulta desde ownexis.com" : "Enquiry from ownexis.com";
    var body = (isES
      ? "Nombre: " + d.name + "\nTeléfono: " + d.phone + "\nEmail: " + d.email + "\n\nNota:\n" + d.note
      : "Name: " + d.name + "\nPhone: " + d.phone + "\nEmail: " + d.email + "\n\nNote:\n" + d.note);
    window.location.href = "mailto:" + FORM_RECIPIENT +
      "?subject=" + encodeURIComponent(subject) + "&body=" + encodeURIComponent(body);
  }

  form.addEventListener("submit", function (e) {
    e.preventDefault();

    /* honeypot: silently accept and do nothing else */
    if (form.elements["company_website"] && form.elements["company_website"].value) {
      openModal();
      return;
    }

    var required = ["name", "email", "note"];
    for (var i = 0; i < required.length; i++) {
      var f = form.elements[required[i]];
      if (!f.value.trim() || !f.checkValidity()) {
        f.focus();
        f.reportValidity && f.reportValidity();
        return;
      }
    }

    var data = {
      name: form.elements["name"].value.trim(),
      phone: form.elements["phone"] ? form.elements["phone"].value.trim() : "",
      email: form.elements["email"].value.trim(),
      note: form.elements["note"].value.trim(),
      language: isES ? "es" : "en",
      _subject: isES ? "Consulta desde ownexis.com" : "Enquiry from ownexis.com"
    };

    var btn = document.getElementById("cf-submit");
    var label = btn ? btn.textContent : "";

    if (!FORM_ENDPOINT) {
      mailtoFallback(data);
      form.reset();
      openModal();
      return;
    }

    if (btn) { btn.disabled = true; btn.textContent = isES ? "Enviando…" : "Sending…"; }

    fetch(FORM_ENDPOINT, {
      method: "POST",
      headers: { "Content-Type": "application/json", "Accept": "application/json" },
      body: JSON.stringify(data)
    }).then(function (res) {
      if (!res.ok) throw new Error("bad status");
      form.reset();
      openModal();
    }).catch(function () {
      mailtoFallback(data);
      openModal();
    }).then(function () {
      if (btn) { btn.disabled = false; btn.textContent = label; }
    });
  });
})();
